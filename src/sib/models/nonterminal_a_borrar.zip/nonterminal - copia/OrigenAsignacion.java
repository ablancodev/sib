package sib.models.nonterminal;

public interface OrigenAsignacion {

	public OrigenAsignacion run();

}
