package sib.models.nonterminal;

public class TipoNumero extends OperandoAritmetico implements OrigenAsignacion {

	String valor;
	String tipo;

	public TipoNumero( String num, String t ) {
		valor = num;
		tipo = t;
	}

	/**
	 * Devuelve el valor
	 */
	public TipoNumero run() {
		return this;
	}
}
