package sib.models.nonterminal;

public abstract class Operacion implements OrigenAsignacion {

	public Variable run() {
		return null;
	}
}
