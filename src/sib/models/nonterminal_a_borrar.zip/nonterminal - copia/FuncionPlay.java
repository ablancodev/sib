package sib.models.nonterminal;

public class FuncionPlay {

	public FuncionPlay() {
		
	}

	public void play( Variable v ) {
		// @todo implementar el método play
	}
}
