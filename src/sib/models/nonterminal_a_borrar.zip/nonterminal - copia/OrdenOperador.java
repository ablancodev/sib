package sib.models.nonterminal;

import java.util.ArrayList;
import java.util.ListIterator;

public class OrdenOperador extends Orden {

	Variable variable;
	ArrayList<String> listaOperadores;
	
	public OrdenOperador( Variable v, String on ) {
		variable = v;
		listaOperadores = new ArrayList<String>();
		listaOperadores.add( on );
	}

	public void addOperadorNota( String op ) {
		listaOperadores.add( op );
	}


	public Variable run() {
		String temp;
		ListIterator<String> it = listaOperadores.listIterator();
		while ( it.hasNext() ) {
			temp = it.next();
			variable.aplicarOperador( temp );
		}
		return variable;
	}

	public void run( TablaSimbolos ts ) {
		String temp;
		ListIterator<String> it = listaOperadores.listIterator();
		while ( it.hasNext() ) {
			temp = it.next();
			variable.aplicarOperador( temp );
		}
		ts.updateVariable( variable );
	}


}
