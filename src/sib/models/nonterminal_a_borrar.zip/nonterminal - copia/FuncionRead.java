package sib.models.nonterminal;

public class FuncionRead {

	public FuncionRead() {
	
	}

	public Variable readNote() {
		Variable v = null;
		// @todo implementar readNote
		return v;
	}
}
