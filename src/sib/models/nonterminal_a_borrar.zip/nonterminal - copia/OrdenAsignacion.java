package sib.models.nonterminal;

public class OrdenAsignacion extends Orden {

	Variable variable;
	OrigenAsignacion origenAsignacion;

	public OrdenAsignacion( Variable v, OrigenAsignacion oa ) {
		variable = v;
		origenAsignacion = oa;
	}

	public OrdenAsignacion( String propiedad_todo, OrigenAsignacion oa ) {
		// @todo falta por ver qué hacemos con las PROPIEDADES, y cómo las tratamos
	}

	@Override
	public void run( TablaSimbolos ts ) {
		variable.setValue( origenAsignacion.run() );
	}

}
