package sib.models.nonterminal;

public class Declaracion implements Instruccion {

	String tipo;
	ListaVariables variables;

	public Declaracion( String tipo, ListaVariables lv ) {
		this.tipo = tipo;
		this.variables = lv;
	}

	@Override
	public void run( TablaSimbolos ts) {
		variables.setTipo( tipo );
		variables.run( ts, tipo );
	}

}
