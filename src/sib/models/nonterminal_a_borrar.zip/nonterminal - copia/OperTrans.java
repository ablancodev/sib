package sib.models.nonterminal;

public class OperTrans extends Operacion {

	Variable variable;
	Operacion operacion;
	OrdenOperador operador;

	TipoNumero tipoNumero;

	public OperTrans( Variable v, TipoNumero tn ) {
		operacion = null;
		operador = null;
		variable = v;
		tipoNumero = tn;
	}

	public OperTrans( Operacion op, TipoNumero tn ) {
		operacion = op;
		operador = null;
		variable = null;
		tipoNumero = tn;
	}

	public OperTrans( OrdenOperador od, TipoNumero tn ) {
		operacion = null;
		operador = od;
		variable = null;
		tipoNumero = tn;
	}

	public Variable run() {
		if ( variable != null ) {
			variable.trans( tipoNumero.toString() );
			return variable;
		}
		if ( operador != null ) {
			Variable v = operador.run();
			v.trans( tipoNumero.toString() );
			return v;
		}
		if ( operacion != null ) {
			Variable v = operacion.run();
			v.trans( tipoNumero.toString() );
			return v;
		}
		return null;
	}
}
