package sib.models.nonterminal;


public class Variable extends OperandoAritmetico implements OrigenAsignacion {

	String name;
	String tipo;
	String valor; // @todo probablemente no sea string

	public Variable(String n ) {
		name = n;
	}

	public void setTipo( String t ) {
		tipo = t;
	}

	/**
	 * Devuelve el valor
	 */
	public Variable run() {
		return this;
	}

	public void aplicarOperador(String temp) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * Transporta un nota un tipo_numero determinado.
	 * @todo de momento sin implementar, simplemente apendizo txt para pruebas
	 *
	 * @param n String ( TipoNumero )
	 */
	public void trans( String n ) {
		valor += n;
		// TODO Auto-generated method stub
		
	}

	public void setValue(OrigenAsignacion oa) {
		// TODO Auto-generated method stub
		this.valor = oa.toString();
	}
}
