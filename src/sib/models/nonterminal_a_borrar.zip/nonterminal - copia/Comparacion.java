package sib.models.nonterminal;

public class Comparacion {

	OrigenAsignacion operador1;
	OrigenAsignacion operador2;
	String condicion;

	public Comparacion( OrigenAsignacion op1, String cc, OrigenAsignacion op2 ) {
		operador1 = op1;
		operador2 = op2;
		condicion = cc;
	}

	public boolean evalua() {
		boolean result;
		switch ( condicion ) {
		case "==":
			result = this.igualQue( operador1.run(), operador2.run() ); 
			break;
		case "!=":
			result = this.distintoQue( operador1.run(), operador2.run() ); 
			break;
		case "<":
			result = this.menorQue( operador1.run(), operador2.run() );
			break;
		case "<=":
			result = this.menorIgualQue( operador1.run(), operador2.run() ); 
			break;
		case ">":
			result = this.mayorQue( operador1.run(), operador2.run() ); 
			break;
		case ">=":
			result = this.mayorIgualQue( operador1.run(), operador2.run() ); 
			break;
		default:
			result = false;
			break;
		}
		return result;
	}

	private boolean mayorIgualQue(OrigenAsignacion run, OrigenAsignacion run2) {
		// TODO Auto-generated method stub
		return true;
	}

	private boolean mayorQue(OrigenAsignacion run, OrigenAsignacion run2) {
		// TODO Auto-generated method stub
		return true;
	}

	private boolean menorIgualQue(OrigenAsignacion run, OrigenAsignacion run2) {
		// TODO Auto-generated method stub
		return true;
	}

	private boolean menorQue(OrigenAsignacion run, OrigenAsignacion run2) {
		// TODO Auto-generated method stub
		return true;
	}

	private boolean distintoQue(OrigenAsignacion run, OrigenAsignacion run2) {
		// TODO Auto-generated method stub
		return true;
	}

	private boolean igualQue(OrigenAsignacion run, OrigenAsignacion run2) {
		// TODO Auto-generated method stub
		return true;
	}
}
