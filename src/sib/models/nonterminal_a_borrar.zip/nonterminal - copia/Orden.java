package sib.models.nonterminal;

public abstract class Orden implements Instruccion {

	public void run( TablaSimbolos ts ) {
		
	}
}
