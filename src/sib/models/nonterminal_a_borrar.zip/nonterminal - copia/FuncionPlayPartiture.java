package sib.models.nonterminal;

public class FuncionPlayPartiture {

	public FuncionPlayPartiture() {
		
	}

	public void playPartiture() {
		// @todo implementar el metodo playPartiture
	}
}
