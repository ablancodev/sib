package sib.models.nonterminal;

public class FuncionReadPartiture {

	public FuncionReadPartiture() {
		
	}

	public void readPartiture() {
		// @todo implementar el metodo playPartiture
	}
}
