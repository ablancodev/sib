package sib.models.nonterminal;

public interface Instruccion {

	public void run( TablaSimbolos ts );
}
