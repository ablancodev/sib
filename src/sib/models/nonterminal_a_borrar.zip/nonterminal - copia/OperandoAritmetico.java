package sib.models.nonterminal;

public abstract class OperandoAritmetico {

	public OperandoAritmetico run() {
		return null;
	}
}
