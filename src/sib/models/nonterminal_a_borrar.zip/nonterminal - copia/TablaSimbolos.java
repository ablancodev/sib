package sib.models.nonterminal;

import java.util.HashMap;
import java.util.Map.Entry;

import sib.controllers.ViewsControllerFase1;

public class TablaSimbolos {

	HashMap<String,Variable> vars;

	public void addVariable(Variable v, String tipo) {
		v.tipo = tipo;
		vars.put( v.name, v );
	}

	public void updateVariable(Variable v ) {
		vars.put( v.name, v );
	}

	public void print( ViewsControllerFase1 vc ) {
		for ( Entry<String, Variable> v : vars.entrySet()) {
			String key = v.getKey();
			Variable value = v.getValue();
			vc.printOutput( "\n TS--------->:" + key + ":" + value );
		}
		
	}

}
