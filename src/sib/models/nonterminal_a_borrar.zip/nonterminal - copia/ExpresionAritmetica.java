package sib.models.nonterminal;

public abstract class ExpresionAritmetica implements OrigenAsignacion {

	public OrigenAsignacion run() {
		return null;
	}

}
